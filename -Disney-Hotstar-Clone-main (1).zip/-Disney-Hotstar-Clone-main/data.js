let movies=[
    {
        name:"Baahubali 2: The Conclusion",
        des:"Why did Kattappa Kill Amerendra Baahubali? Unvell the mystery and many more secrets that lie in the depths of the Mahishmati kingdom.",
        image:"images/s1.jpg"
    },
    {
        name:"K.G.F: Chapter 2",
        des:"Rocky successfully rises as the leader and saviour of the people of the Kolar Gold Fields. But, in his goal to fulfil his mother's wishes, Rocky must tackle Adheera, Inayat Khalil and Ramika Sen.",
        image:"images/s2.jpg"
    },
    {
        name:"Avengers: Endgame",
        des:"After Thanos, an intergalactic warlord, disintegrates half of the universe, the Avengers must reunite and assemble again to reinvigorate their trounced allies and restore balance.",
        image:"images/s3.jpg"
    },
    {
        name:"Bigg Boss",
        des:"Contestants from all walks of life are locked in a common house. They compete against each other to win a cash prize by saving themselves from eliminations based on public votes.",
        image:"images/s4.webp"
    },
    {
        name:"Dunki",
        des:"A group of friends use a backdoor process to move to another country, then struggle to return home.",
        image:"images/s5.jpg"
    },
    {
        name:"Guppedantha Manasu",
        des:"Life brings headstrong Vasudhara to clash with Rishi, an arrogant professor. What's in store for this pair of chalk and cheese?",
        image:"images/s6.webp"
    }
]
